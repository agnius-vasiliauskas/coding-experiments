﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Centroid
{
    public static class Input
    {
        public static void UpdateInput(Game game)
        {
            MouseState mouseAttributes = Mouse.GetState();
            game.IsMouseVisible = true;
            game.mousePosition = new Vector2(mouseAttributes.X, mouseAttributes.Y);

            if (Keyboard.GetState().IsKeyDown(Keys.Escape)) game.Exit();

            if (mouseAttributes.MiddleButton == ButtonState.Pressed) 
                game.drawShape = true;

            if (mouseAttributes.RightButton == ButtonState.Pressed)
            {
                game.points = new Vector2[100];
                game.index = -1;
                game.drawShape = false;
                game.drawCentroid = false;
                game.drawWarning = false;
            }

            if (mouseAttributes.LeftButton == ButtonState.Pressed && !game.drawShape && game.index < 99)
            {
                if (game.index == -1)
                {
                    game.index++;
                    game.points[game.index] = game.mousePosition;
                }
                else if (game.points[game.index] != game.mousePosition)
                {
                    game.index++;
                    game.points[game.index] = game.mousePosition;
                }
            }

        }

    }
}
