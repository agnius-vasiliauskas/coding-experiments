﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;


namespace Centroid
{
    public static class Primitive
    {
        public static Texture2D CreatePixelTexture(GraphicsDevice GraphicsDevice)
        {
            int TargetWidth = 6;
            int TargetHeight = 6;
            RenderTarget2D LevelRenderTarget = new RenderTarget2D(GraphicsDevice, TargetWidth, TargetHeight, 1, GraphicsDevice.PresentationParameters.BackBufferFormat, GraphicsDevice.PresentationParameters.MultiSampleType, GraphicsDevice.PresentationParameters.MultiSampleQuality, RenderTargetUsage.PreserveContents);
            DepthStencilBuffer stencilBuffer = new DepthStencilBuffer(GraphicsDevice, TargetWidth, TargetHeight, GraphicsDevice.DepthStencilBuffer.Format, GraphicsDevice.PresentationParameters.MultiSampleType, GraphicsDevice.PresentationParameters.MultiSampleQuality);
            GraphicsDevice.SetRenderTarget(0, LevelRenderTarget);
            DepthStencilBuffer old = GraphicsDevice.DepthStencilBuffer;
            GraphicsDevice.DepthStencilBuffer = stencilBuffer;
            GraphicsDevice.Clear(Color.White);
            GraphicsDevice.SetRenderTarget(0, null);
            GraphicsDevice.DepthStencilBuffer = old;
            return LevelRenderTarget.GetTexture();
        }

        public static void DrawLine(SpriteBatch sprite, Vector2 start, Vector2 end, Color color, Texture2D pixel)
        {
            int distance = (int)Vector2.Distance(start, end);
            Vector2 connection = end - start;
            Vector2 baseVector = new Vector2(1, 0);
            float alpha = (float)Math.Atan2(end.Y - start.Y, end.X - start.X);
            if (pixel != null)
                sprite.Draw(pixel, new Rectangle((int)start.X, (int)start.Y, distance, 1), null, color, alpha, new Vector2(0, 0), SpriteEffects.None, 0);
        }

    }
}
