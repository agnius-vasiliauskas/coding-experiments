﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Centroid
{
    public static class Geometry
    {
        private enum ClockDir
        {
            CLOCKWISE = -1,
            COUNTER_CLOCKWISE = 1,
            LINE = 0
        }

        public static bool PolySelfIntersects(Vector2[] points, int lastPointIndex)
        {
            int k, n;
            bool test;

            for (int i = 0; i <= lastPointIndex; i++)
            {
                k = (i + 1) % (lastPointIndex + 1);
                for (int j = 0; j <= lastPointIndex; j++)
                {
                    n = (j + 1) % (lastPointIndex + 1);
                    if (i != j && k != j && n != i)
                    {
                        test = LinesIntersect(points[i], points[k], points[j], points[n]);
                        if (test) return true;
                    }
                }
            }

            return false;
        }

        private static ClockDir PointsDirection(Vector2 pt1, Vector2 pt2, Vector2 pt3)
        {
            float test;
            test = (((pt2.X - pt1.X) * (pt3.Y - pt1.Y)) - ((pt3.X - pt1.X) * (pt2.Y - pt1.Y)));

            if (test > 0) return ClockDir.COUNTER_CLOCKWISE;
            else if (test < 0) return ClockDir.CLOCKWISE;
            else return ClockDir.LINE;
        }

        private static bool LinesIntersect(Vector2 l1p1, Vector2 l1p2, Vector2 l2p1, Vector2 l2p2)
        {
            ClockDir test1_a, test1_b, test2_a, test2_b;

            test1_a = PointsDirection(l1p1, l1p2, l2p1);
            test1_b = PointsDirection(l1p1, l1p2, l2p2);
            if (test1_a != test1_b)
            {
                test2_a = PointsDirection(l2p1, l2p2, l1p1);
                test2_b = PointsDirection(l2p1, l2p2, l1p2);
                if (test2_a != test2_b)
                {
                    return true;
                }
            }
            return false;
        }

        public static Vector2 CalculateCentroid(Vector2[] points, int lastPointIndex)
        {
            float area = 0.0f;
            float Cx = 0.0f;
            float Cy = 0.0f;
            float tmp = 0.0f;
            int k;

            for (int i = 0; i <= lastPointIndex; i++)
            {
                k = (i + 1) % (lastPointIndex + 1);
                tmp = points[i].X * points[k].Y - points[k].X * points[i].Y;
                area += tmp;
                Cx += (points[i].X + points[k].X) * tmp;
                Cy += (points[i].Y + points[k].Y) * tmp;
            }
            area *= 0.5f;
            Cx *= 1.0f / (6.0f * area);
            Cy *= 1.0f / (6.0f * area);

            return new Vector2(Cx, Cy);
        }

    }
}
