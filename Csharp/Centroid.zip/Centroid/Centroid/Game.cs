using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Centroid
{
    public class Game : Microsoft.Xna.Framework.Game
    {
        Texture2D pixel;
        SpriteBatch spriteBatch;
        SpriteFont Font1;
        GraphicsDeviceManager graphics;
        public Vector2 mousePosition;
        Vector2 centroid;
        public Vector2[] points = new Vector2[100];
        public int index = -1;
        public bool drawShape = false;
        public bool drawCentroid = false;
        public bool drawWarning = false;
        int lastHash = 0;

        public Game()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferHeight = 400;
            graphics.PreferredBackBufferWidth = 400;

        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Font1 = Content.Load<SpriteFont>("BuiltFont");
            pixel = Primitive.CreatePixelTexture(GraphicsDevice);
        }

        protected override void Update(GameTime gameTime)
        {
            Input.UpdateInput(this);

            if (drawShape) 
            {
                // Recalculate polygon parameters only when polygon changes
                if (lastHash != points.GetHashCode())
                {
                    lastHash = points.GetHashCode();
                    centroid = Geometry.CalculateCentroid(points, index);

                    if (Geometry.PolySelfIntersects(points, index))
                        drawWarning = true;
                    else
                        drawCentroid = true;
                }
            }

            base.Update(gameTime);
        }
        
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

            for (int i = 0; i <= index; i++)
            {
                spriteBatch.Draw(pixel, new Vector2(points[i].X - 3, points[i].Y - 3), Color.Yellow);
                if (drawShape && index > 1)
                {
                    Primitive.DrawLine(spriteBatch, points[i], points[(i+1)%(index+1)], Color.Red, pixel);
                    if (drawCentroid) 
                        Primitive.DrawLine(spriteBatch, points[i], centroid, Color.LightBlue, pixel);
                }
            }
            if (drawCentroid)
                spriteBatch.Draw(pixel, new Vector2(centroid.X-3,centroid.Y-3), Color.Black);

            spriteBatch.DrawString(Font1, "Left click --> Add polygon vertex", new Vector2(10, 10), Color.LightGreen);
            spriteBatch.DrawString(Font1, "Middle click --> Draw polygon", new Vector2(10, 30), Color.LightGreen);
            spriteBatch.DrawString(Font1, "Right click --> Clear screen", new Vector2(10, 50), Color.LightGreen);

            if (drawWarning)
                spriteBatch.DrawString(Font1, "Centroid formula does not apply to self-intersecting polygons !!!", new Vector2(10, 350), Color.DarkMagenta);

            spriteBatch.End();

            base.Draw(gameTime);
        }

    }
}
